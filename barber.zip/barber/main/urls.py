



from django.urls import path
from .views import IndexView, AboutView, RegistrView, SuccessView

urlpatterns = [
    path('', IndexView.as_view(), name='index'),
    path('about/', AboutView.as_view(), name='about'),
    path('registr/', RegistrView.as_view(), name='registr'),  # форма регистрации
    path('success/', SuccessView.as_view(), name='success'),  # страница успешной заявки
]
