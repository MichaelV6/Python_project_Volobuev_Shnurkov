from django.shortcuts import render, redirect
from django.views.generic import TemplateView
from .forms import BookingForm
from django.views import View


# Главная страница
class IndexView(TemplateView):
    template_name = 'main/index.html'


# Страница "О нас"
class AboutView(TemplateView):
    template_name = 'main/about.html'


# Страница подтверждения успешной записи
class SuccessView(TemplateView):
    template_name = 'main/success.html'


# Страница записи на стрижку
class RegistrView(View):
    def get(self, request):
        form = BookingForm()
        return render(request, 'main/registr.html', {'form': form})

    def post(self, request):
        form = BookingForm(request.POST)

        haircut_type = request.POST.get('haircut_type')
        if haircut_type == 'classic':
            total_price = 1500
        elif haircut_type == 'fade':
            total_price = 1800
        elif haircut_type == 'buzz':
            total_price = 1200
        elif haircut_type == 'trim':
            total_price = 1000
        else:
            total_price = 0  # Если нет выбора

        if form.is_valid():
            # Присвоение рассчитанной цены форме перед сохранением
            booking = form.save(commit=False)
            booking.total_price = total_price
            booking.save()
            return redirect('success')

        # Если есть ошибки в форме
        print("Ошибка в форме:", form.errors)
        return render(request, 'main/registr.html', {'form': form})
