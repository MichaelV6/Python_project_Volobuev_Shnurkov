from django import forms
from .models import Booking

class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ['first_name', 'last_name', 'phone', 'haircut_type', 'barber', 'appointment_time', 'total_price']
