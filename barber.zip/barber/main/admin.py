from django.contrib import admin
from .models import Booking  # Импортируем модель Booking

@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ['first_name', 'last_name', 'haircut_type', 'appointment_time', 'total_price']  # Поля, которые будут видны в админке
